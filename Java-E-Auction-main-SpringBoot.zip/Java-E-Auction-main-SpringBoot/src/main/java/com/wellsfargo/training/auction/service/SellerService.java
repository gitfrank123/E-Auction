package com.wellsfargo.training.auction.service;

import com.wellsfargo.training.auction.dto.SellerDto;

public interface SellerService {

	public SellerDto registerSeller(SellerDto sellerDto);
	
	public Boolean deleteProduct(Long productId);


}
