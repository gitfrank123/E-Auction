package com.wellsfargo.training.auction.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.dto.BuyerDto;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.service.BidsService;
import com.wellsfargo.training.auction.service.BuyerService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/e-auction/api/v1/buyer")
public class BuyerController {

	@Autowired
	private BuyerService buyerService;

	@Autowired
	private BidsService bidsService;

	@PostMapping("/register")
	public ResponseEntity<BuyerDto> registerBuyer(@Valid @RequestBody BuyerDto buyerDto, BindingResult result) {
		if (buyerDto.getBuyerFirstName().length()<3) {
			throw new InvalidDataException("Buyer data is not Valid!");
		}
		buyerService.registerBuyer(buyerDto);
		return ResponseEntity.ok(buyerDto);
	}

	@SuppressWarnings({})
	@PostMapping("/place-bid")
	public ResponseEntity<BidsDto> placeBid(@Valid @RequestBody BidsDto bidsDto, BindingResult result) {
		bidsService.placeBid(bidsDto);
		return ResponseEntity.ok(bidsDto);

	}

	@PutMapping("/update-bid/{productId}/{buyerEmailld}/{newBidAmount}")
	public ResponseEntity<BidsDto> updateBid(@PathVariable Long productId, @PathVariable String buyerEmailld,
			@PathVariable Double newBidAmount) {				
			BidsDto updateBid = bidsService.updateBid(productId,newBidAmount);
			return ResponseEntity.ok(updateBid);
		
	}
}
