package com.wellsfargo.training.auction.service;

import java.util.List;

import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.entity.BidsEntity;

public interface BidsService {

	public BidsDto placeBid(BidsDto bidsDto);

	public BidsDto updateBid(Long prodId,Double bidAmt);
	
	BidsEntity getBid(Long porductId);

	public List<BidsDto> getAllBidsOnProduct(Long porductId);

}
