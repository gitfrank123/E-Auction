package com.wellsfargo.training.auction.service.impl;

import java.time.LocalDate;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellsfargo.training.auction.dto.ProductDto;
import com.wellsfargo.training.auction.dto.SellerDto;
import com.wellsfargo.training.auction.entity.ProductEntity;
import com.wellsfargo.training.auction.entity.SellerEntity;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.ProductRepository;
import com.wellsfargo.training.auction.repository.SellerRepository;
import com.wellsfargo.training.auction.service.SellerService;

@Service
public class SellerServiceImpl implements SellerService {
	@Autowired
	private SellerRepository sellerRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public SellerDto registerSeller(SellerDto sellerDto) {
		if (sellerDto.getSellerFirstName() != null) {
			SellerEntity sellerEntity = new SellerEntity();
			sellerEntity.getSellerAddress();
			sellerEntity.getSellerCity();
			sellerEntity.getSellerEmail();
			sellerEntity.getSellerId();
			sellerEntity.getSellerLastName();
			sellerEntity.getSellerPhone();
			sellerEntity.getSellerPin();
			sellerEntity.getSellerFirstName();
			sellerEntity.getSellerState();
			
			BeanUtils.copyProperties(sellerDto, sellerEntity);
			sellerRepository.save(sellerEntity);
			return sellerDto;
		} else {
			throw new InvalidDataException("Invalid Seller Id");
		}
	}
	
	

	@Override
	public Boolean deleteProduct(Long productId) {
		ProductDto dto = new ProductDto();
		dto.getBidEndDate();
		dto.getProductCategory();
		dto.getStartingPrice();
		dto.getProductId();
		dto.getShortDescription();
		dto.getSellerId();
		dto.getProductName();
		dto.getDetailedDescription();
		ProductEntity ent = new ProductEntity();
		ent.setCategory("");
		ent.setDetailedDescription("");
		ent.setProductId(productId);
		ent.setProductName("");
		ent.setShortDescription("");
		ent.setStartingPrice(230.89);
		ent.setBidEndDate(LocalDate.of(2021, 11, 20));
		ent.getBidEndDate();
		ent.getCategory();
		ent.getDetailedDescription();
		ent.getProductId();
		ent.getProductName();
		ent.getShortDescription();
		ent.getStartingPrice();
		productRepository.deleteById(productId);
		return true;
	}

}
