package com.wellsfargo.training.auction.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellsfargo.training.auction.dto.BuyerDto;
import com.wellsfargo.training.auction.entity.BuyerEntity;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.BuyerRepository;
import com.wellsfargo.training.auction.service.BuyerService;

@Service
public class BuyerServiceImpl implements BuyerService {

	@Autowired
	private BuyerRepository buyerRepository;

	@Override
	public BuyerDto registerBuyer(BuyerDto buyerDto) {
		if(buyerDto.getBuyerId()!=0) {
		BuyerEntity buyerEntity = new BuyerEntity();
		BeanUtils.copyProperties(buyerDto, buyerEntity);
		buyerRepository.save(buyerEntity);
		return buyerDto;
		}
		else {
			throw new InvalidDataException("Invalid Buyer Data");
		}
	}

	@Override
	public BuyerDto updateBuyer(BuyerDto buyerDto) {
		if(buyerDto.getBuyerId()!=0) {
			BuyerEntity buyerEntity = new BuyerEntity();
			BeanUtils.copyProperties(buyerDto, buyerEntity);
			buyerRepository.save(buyerEntity);
			return buyerDto;
		}	
		
		else {
			throw new InvalidDataException("Update Failed");
		}
		
	}


}
