package com.wellsfargo.training.auction.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.entity.BidsEntity;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.BidsRepository;
import com.wellsfargo.training.auction.service.BidsService;

@Service
public class BidsServiceImpl implements BidsService {

	@Autowired
	private BidsRepository bidsRepository;

	@Override
	public BidsDto placeBid(BidsDto bidsDto) {
		if (bidsDto.getBidId() != 0) {
			BidsEntity bidsEntity = new BidsEntity();
			BeanUtils.copyProperties(bidsDto, bidsEntity);
			bidsRepository.save(bidsEntity);
			return bidsDto;
		} else {
			throw new InvalidDataException("Bid not Placed");
		}
	}

	@Override
	public List<BidsDto> getAllBidsOnProduct(Long porductId) {
		if (porductId != 0) {
			List<BidsEntity> bids = bidsRepository.getBidsByProductId(porductId);
			List<BidsDto> bidsDtos = new ArrayList<>();
			for (BidsEntity entity : bids) {
				BidsDto bidsDto = new BidsDto();
				BeanUtils.copyProperties(entity, bidsDto);
				bidsDtos.add(bidsDto);
			}
			return bidsDtos;
		} else {
			throw new InvalidDataException("Product Should not be 0");
		}
	}

	@Override
	public BidsDto updateBid(Long prodId, Double bidAmt) {
		BidsEntity bid = getBid(prodId);
		BidsDto bidsDto = new BidsDto();
		if (prodId != 0) {
			if (bid != null) {
				bid.setBidAmount(bidAmt);
				bidsRepository.save(bid);
				BeanUtils.copyProperties(bid, bidsDto);
				return bidsDto;
			}
			throw new InvalidDataException("Bid Not Found");
		} else {
			throw new InvalidDataException("Invalid Product Id");
		}
	}

	@Override
	public BidsEntity getBid(Long prodId) {
		return bidsRepository.getBidByProductId(prodId);
	}
}