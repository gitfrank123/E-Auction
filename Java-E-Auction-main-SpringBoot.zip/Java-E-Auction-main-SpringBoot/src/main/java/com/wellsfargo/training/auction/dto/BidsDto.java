package com.wellsfargo.training.auction.dto;

import java.time.LocalDate;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BidsDto {
	
	private Long bidId;
	@NotNull
	private Double bidAmount;
	@NotNull
	@JsonFormat(pattern = "yyyy-MM-dd")
	private LocalDate biddingDate;
	@NotNull
	private Long productId;
	@NotNull
	private Long buyerId;
	public Long getBidId() {
		return bidId;
	}
	public void setBidId(Long bidId) {
		this.bidId = bidId;
	}
	public Double getBidAmount() {
		return bidAmount;
	}
	public void setBidAmount(Double bidAmount) {
		this.bidAmount = bidAmount;
	}
	public LocalDate getBiddingDate() {
		return biddingDate;
	}
	public void setBiddingDate(LocalDate biddingDate) {
		this.biddingDate = biddingDate;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Long buyerId) {
		this.buyerId = buyerId;
	}
	
	
	
	
	
	
}
