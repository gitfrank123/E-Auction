package com.wellsfargo.training.auction.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "bids")
public class BidsEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bid_id")
	private Long bidId;
	
	@Column(name="buyer_id")
	private Long buyerId;
	
	@Column(name="bidding_date")
	private LocalDate biddingDate;
	
	@Column(name="product_id")
	private Long productId;
	
	@Column(name="bid_amount")
	private Double bidAmount;

	public Long getBidId() {
		return bidId;
	}

	public void setBidId(Long bidId) {
		this.bidId = bidId;
	}

	public Long getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Long buyerId) {
		this.buyerId = buyerId;
	}

	

	public LocalDate getBiddingDate() {
		return biddingDate;
	}

	public Long getProductId() {
		return productId;
	}

	public Double getBidAmount() {
		return bidAmount;
	}

	public void setBiddingDate(LocalDate biddingDate) {
		this.biddingDate = biddingDate;
	}

	

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	

	public void setBidAmount(Double bidAmount) {
		this.bidAmount = bidAmount;
	}
	
	
	
}
