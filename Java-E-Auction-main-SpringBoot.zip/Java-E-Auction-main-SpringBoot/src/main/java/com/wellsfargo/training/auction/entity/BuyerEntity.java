package com.wellsfargo.training.auction.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "buyer")
@Getter
@Setter
public class BuyerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="buyer_id")
	private Long buyerId;
	
	@Column(name="buyer_first_name")
	private String buyerFirstName;
	
	@Column(name="buyer_last_name")
	private String buyerLastName;
	
	@Column(name="buyer_address")
	private String buyerAddress;
	
	@Column(name="buyer_city")
	private String buyerCity;
	
	@Column(name="buyer_state")
	private String buyerState;
	
	@Column(name="buyer_pin")
	private String buyerPin;
	
	@Column(name="buyer_phone")
	private Long buyerPhone;
	
	@Column(name="buyer_email")
	private String buyerEmail;
	
}
