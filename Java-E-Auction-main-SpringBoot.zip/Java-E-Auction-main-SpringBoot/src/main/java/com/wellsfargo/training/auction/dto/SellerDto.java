package com.wellsfargo.training.auction.dto;


import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;


public class SellerDto {
	
	private Long sellerId;
	@NotBlank
	@Length(min = 5, max = 30)
	private String sellerFirstName;
	
	@NotBlank
	@Length(min = 3, max = 25)
	private String sellerLastName;
	
	@NotBlank
	@Email
	private String sellerEmail;
	
	@NotBlank
	private String sellerAddress;
	
	@NotBlank
	private String sellerCity;
	
	@NotBlank
	private String sellerState;
	
	@NotNull
	@Min(100000)
	@Max(999999L)
	private Long sellerPin;

	@NotNull
	@Min(1000000000)
	@Max(9999999999L)
	private Long sellerPhone;

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerFirstName() {
		return sellerFirstName;
	}

	public void setSellerFirstName(String sellerFirstName) {
		this.sellerFirstName = sellerFirstName;
	}

	public String getSellerLastName() {
		return sellerLastName;
	}

	public void setSellerLastName(String sellerLastName) {
		this.sellerLastName = sellerLastName;
	}

	public String getSellerEmail() {
		return sellerEmail;
	}

	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}

	public String getSellerAddress() {
		return sellerAddress;
	}

	public void setSellerAddress(String sellerAddress) {
		this.sellerAddress = sellerAddress;
	}

	public String getSellerCity() {
		return sellerCity;
	}

	public void setSellerCity(String sellerCity) {
		this.sellerCity = sellerCity;
	}

	public String getSellerState() {
		return sellerState;
	}

	public void setSellerState(String sellerState) {
		this.sellerState = sellerState;
	}

	public Long getSellerPin() {
		return sellerPin;
	}

	public void setSellerPin(Long sellerPin) {
		this.sellerPin = sellerPin;
	}

	public Long getSellerPhone() {
		return sellerPhone;
	}

	public void setSellerPhone(Long sellerPhone) {
		this.sellerPhone = sellerPhone;
	}
	

}
