package com.wellsfargo.training.auction.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sellers")
public class SellerEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="seller_id")
	private Long sellerId;
	
	@Column(name="seller_first_name")
	private String sellerFirstName;
	
	@Column(name="seller_last_name")
	private String sellerLastName;
	
	@Column(name="seller_address")
	private String sellerAddress;
	
	@Column(name="seller_city")
	private String sellerCity;
	
	@Column(name="seller_state")
	private String sellerState;
	
	@Column(name="seller_pin")
	private Long sellerPin;
	
	@Column(name="seller_phone")
	private Long sellerPhone;
	
	@Column(name="seller_email")
	private String sellerEmail;

	public Long getSellerId() {
		return sellerId;
	}

	public void setSellerId(Long sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerFirstName() {
		return sellerFirstName;
	}

	public void setSellerFirstName(String sellerFirstName) {
		this.sellerFirstName = sellerFirstName;
	}

	public String getSellerLastName() {
		return sellerLastName;
	}

	public void setSellerLastName(String sellerLastName) {
		this.sellerLastName = sellerLastName;
	}

	public String getSellerAddress() {
		return sellerAddress;
	}

	public void setSellerAddress(String sellerAddress) {
		this.sellerAddress = sellerAddress;
	}

	public String getSellerCity() {
		return sellerCity;
	}

	public void setSellerCity(String sellerCity) {
		this.sellerCity = sellerCity;
	}

	public String getSellerState() {
		return sellerState;
	}

	public void setSellerState(String sellerState) {
		this.sellerState = sellerState;
	}

	public Long getSellerPin() {
		return sellerPin;
	}

	public void setSellerPin(Long sellerPin) {
		this.sellerPin = sellerPin;
	}

	public Long getSellerPhone() {
		return sellerPhone;
	}

	public void setSellerPhone(Long sellerPhone) {
		this.sellerPhone = sellerPhone;
	}

	public String getSellerEmail() {
		return sellerEmail;
	}

	public void setSellerEmail(String sellerEmail) {
		this.sellerEmail = sellerEmail;
	}
	
	
	
}
