package com.wellsfargo.training.auction.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;


public class BuyerDto {
	
	@NotNull
	private Long buyerId;
	
	@NotBlank
	@Length(min = 5, max = 30)
	private String buyerFirstName;
	
	@NotBlank
	@Length(min = 3, max = 25)
	private String buyerLastName;
	
	@NotBlank
	@Email
	private String buyerEmail;
	
	@NotNull
	@Min(1000000000)
	@Max(9999999999L)
	private Long buyerPhone;
	
	@NotBlank
	private String buyerAddress;

	@NotBlank
	private String buyerCity;
	
	@NotBlank
	private String buyerState;
	
	@NotNull
	@Min(100000)
	@Max(999999L)
	private Long buyerPin;

	public Long getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(Long buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerFirstName() {
		return buyerFirstName;
	}

	public void setBuyerFirstName(String buyerFirstName) {
		this.buyerFirstName = buyerFirstName;
	}

	public String getBuyerLastName() {
		return buyerLastName;
	}

	public void setBuyerLastName(String buyerLastName) {
		this.buyerLastName = buyerLastName;
	}

	public String getBuyerEmail() {
		return buyerEmail;
	}

	public void setBuyerEmail(String buyerEmail) {
		this.buyerEmail = buyerEmail;
	}

	public Long getBuyerPhone() {
		return buyerPhone;
	}

	public void setBuyerPhone(Long buyerPhone) {
		this.buyerPhone = buyerPhone;
	}

	public String getBuyerAddress() {
		return buyerAddress;
	}

	public void setBuyerAddress(String buyerAddress) {
		this.buyerAddress = buyerAddress;
	}

	public String getBuyerCity() {
		return buyerCity;
	}

	public void setBuyerCity(String buyerCity) {
		this.buyerCity = buyerCity;
	}

	public String getBuyerState() {
		return buyerState;
	}

	public void setBuyerState(String buyerState) {
		this.buyerState = buyerState;
	}

	public Long getBuyerPin() {
		return buyerPin;
	}

	public void setBuyerPin(Long buyerPin) {
		this.buyerPin = buyerPin;
	}

	

	
}
