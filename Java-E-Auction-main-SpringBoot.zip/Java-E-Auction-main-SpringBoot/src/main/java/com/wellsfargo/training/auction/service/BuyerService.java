package com.wellsfargo.training.auction.service;

import com.wellsfargo.training.auction.dto.BuyerDto;

public interface BuyerService {
	public BuyerDto registerBuyer(BuyerDto customerDto);

	public BuyerDto updateBuyer(BuyerDto customerDto);


}
