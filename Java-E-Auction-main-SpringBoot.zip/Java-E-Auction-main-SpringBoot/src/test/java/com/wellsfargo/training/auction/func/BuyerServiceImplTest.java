package com.wellsfargo.training.auction.func;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.wellsfargo.training.auction.dto.BuyerDto;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.BuyerRepository;
import com.wellsfargo.training.auction.service.impl.BuyerServiceImpl;
import com.wellsforgo.testutils.MasterData;

@ExtendWith(MockitoExtension.class)
 class BuyerServiceImplTest {

	@Mock
	BuyerRepository buyerRepo;
	@InjectMocks
	BuyerServiceImpl buyerImpl;

	@Test
	void testBuyerRegister() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		BuyerDto registerBuyer = buyerImpl.registerBuyer(buyerDto);
		assertEquals(registerBuyer, buyerDto);

	}

	@Test
	void testBuyerRegisterInvaidData() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		buyerDto.setBuyerId(0L);
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> buyerImpl.registerBuyer(buyerDto))
				.withMessage("Invalid Buyer Data");
	}
	
	@Test
	void testUpdateBuyer() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		BuyerDto registerBuyer = buyerImpl.updateBuyer(buyerDto);
		assertEquals(registerBuyer, buyerDto);

	}

	@Test
	void testUpdateBuyerInvaidData() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		buyerDto.setBuyerId(0L);
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> buyerImpl.updateBuyer(buyerDto))
				.withMessage("Update Failed");
	}

}
