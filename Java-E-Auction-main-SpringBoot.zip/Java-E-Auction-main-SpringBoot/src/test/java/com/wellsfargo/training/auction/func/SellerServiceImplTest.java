package com.wellsfargo.training.auction.func;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.wellsfargo.training.auction.dto.SellerDto;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.ProductRepository;
import com.wellsfargo.training.auction.repository.SellerRepository;
import com.wellsfargo.training.auction.service.impl.SellerServiceImpl;
import com.wellsforgo.testutils.MasterData;

@ExtendWith(MockitoExtension.class)
 class SellerServiceImplTest {

	@Mock
	SellerRepository sellerRepo;
	@Mock
	ProductRepository productRepository;
	@InjectMocks
	SellerServiceImpl sellerImpl;

	@Test
	void testSellerRegister() throws Exception {
		SellerDto sellerDto = MasterData.getSellerDto();
		SellerDto registerSeller = sellerImpl.registerSeller(sellerDto);
		assertEquals(registerSeller, sellerDto);

	}

	@Test
	void testSellerRegisterInvaidData() throws Exception {
		SellerDto sellerDto = MasterData.getSellerDto();
		sellerDto.setSellerFirstName(null);
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> sellerImpl.registerSeller(sellerDto))
				.withMessage("Invalid Seller Id");
	}

	@Test
	void testDeleteSeller() throws Exception {
		Boolean deleteProduct = sellerImpl.deleteProduct(2L);
		if (deleteProduct) {
			assertTrue(true);
		}
	}

}
