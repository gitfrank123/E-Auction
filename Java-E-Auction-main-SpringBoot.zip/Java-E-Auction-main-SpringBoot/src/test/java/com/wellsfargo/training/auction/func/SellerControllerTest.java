package com.wellsfargo.training.auction.func;

import static com.wellsforgo.testutils.TestUtils.businessTestFile;
import static com.wellsforgo.testutils.TestUtils.currentTest;
import static com.wellsforgo.testutils.TestUtils.testReport;
import static com.wellsforgo.testutils.TestUtils.WFAssert;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.wellsfargo.training.auction.controller.SellerController;
import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.dto.ProductDto;
import com.wellsfargo.training.auction.dto.SellerDto;
import com.wellsfargo.training.auction.repository.ProductRepository;
import com.wellsfargo.training.auction.service.BidsService;
import com.wellsfargo.training.auction.service.SellerService;
import com.wellsforgo.testutils.MasterData;

@WebMvcTest(SellerController.class)
@AutoConfigureMockMvc
public class SellerControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	 SellerService sellerService ;
	
	@MockBean
	private BidsService bidsService;
	
	

	@AfterAll
	public static void afterAll() {
		testReport();
	}

	
	
	
	@Test
	void testRegisterSeller() throws Exception {
		SellerDto sellerDto = MasterData.getSellerDto();
		SellerDto savedSellerDto = MasterData.getSellerDto();
		savedSellerDto.setSellerId(1L);
		when(this.sellerService.registerSeller(sellerDto)).thenReturn(savedSellerDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-auction/api/v1/seller/add-product")
				.content(MasterData.asJsonString(sellerDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		WFAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(savedSellerDto))
						? "true"
						: "false"),
				businessTestFile);

	}
	
	@Test
	void testDeleteProduct() throws Exception {
		ProductDto productDto = MasterData.getProductDto();
		productDto.setProductId(1L);
		when(this.sellerService.deleteProduct(1L)).thenReturn(true);		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.delete("/e-auction/api/v1/seller/delete/1")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		WFAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(true)) ? "true"
						: "false"),
				businessTestFile);

	}
	
	
	

	@Test
	void testGetAllBidsOnProduct() throws Exception {
		List<BidsDto> bidsDtos = MasterData.getBidsDtoList();

		when(this.bidsService.getAllBidsOnProduct(1L)).thenReturn(bidsDtos);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/e-auction/api/v1/seller/show-bids/1")
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		WFAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(bidsDtos)) ? "true"
						: "false"),
				businessTestFile);

	}

}
