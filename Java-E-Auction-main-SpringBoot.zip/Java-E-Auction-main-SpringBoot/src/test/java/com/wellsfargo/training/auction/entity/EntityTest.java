package com.wellsfargo.training.auction.entity;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsforgo.testutils.MasterData;

@WebMvcTest(BidsDto.class)
public class EntityTest {
	
	@Test
	public void testBidAmount() {
		Double bidAmount = (double) 12000;
		BidsDto bidsDto = MasterData.getBidsDto();
		bidsDto.setBidAmount(bidAmount);
		bidAmount = bidsDto.getBidAmount();
		assertEquals(bidAmount, bidsDto.getBidAmount());
	} 

}
