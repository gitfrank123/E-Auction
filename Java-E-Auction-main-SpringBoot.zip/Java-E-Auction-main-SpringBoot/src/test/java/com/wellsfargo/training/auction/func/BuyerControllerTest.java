package com.wellsfargo.training.auction.func;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.wellsfargo.training.auction.controller.BuyerController;
import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.dto.BuyerDto;
import com.wellsfargo.training.auction.service.BidsService;
import com.wellsfargo.training.auction.service.BuyerService;
import com.wellsforgo.testutils.MasterData;
import static com.wellsforgo.testutils.TestUtils.testReport;
import static com.wellsforgo.testutils.TestUtils.businessTestFile;
import static com.wellsforgo.testutils.TestUtils.exceptionTestFile;
import static com.wellsforgo.testutils.TestUtils.currentTest;
import static com.wellsforgo.testutils.TestUtils.WFAssert;

@WebMvcTest(BuyerController.class)
@AutoConfigureMockMvc
public class BuyerControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BuyerService buyerService;

	@MockBean
	private BidsService bidsService;

	@AfterAll
	public static void afterAll() {
		testReport();
	}

	@Test
	void testRegisterBuyer() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		BuyerDto savedbuyerDto = MasterData.getBuyerDto();
		savedbuyerDto.setBuyerId(1L);

		when(this.buyerService.registerBuyer(buyerDto)).thenReturn(savedbuyerDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-auction/api/v1/buyer/register")
				.content(MasterData.asJsonString(buyerDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		WFAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(savedbuyerDto))
						? "true"
						: "false"),
				businessTestFile);

	}

	@Test
	void testPlaceBid() throws Exception {
		BidsDto bidsDto = MasterData.getBidsDto();
		BidsDto savedBidsDto = MasterData.getBidsDto();
		savedBidsDto.setBuyerId(1L);

		when(this.bidsService.placeBid(bidsDto)).thenReturn(savedBidsDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-auction/api/v1/buyer/place-bid")
				.content(MasterData.asJsonString(bidsDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		WFAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(savedBidsDto)) ? "true"
						: "false"),
				businessTestFile);

	}

	@Test
	void testUpdateBid() throws Exception {
		BidsDto bidsDto = MasterData.getBidsDto();
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.put("/e-auction/api/v1/buyer/update-bid/1/www.ff@gmail.com/235.89")
				.content(MasterData.asJsonString(bidsDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertThat(result).isNotNull();
	}

	@Test
	void testRegisterBuyerInvalidDataException() throws Exception {
		BuyerDto buyerDto = MasterData.getBuyerDto();
		BuyerDto savedBuyerDto = MasterData.getBuyerDto();
		savedBuyerDto.setBuyerId(1L);
		buyerDto.setBuyerFirstName("Ab");
		when(this.buyerService.registerBuyer(buyerDto)).thenReturn(savedBuyerDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-auction/api/v1/buyer/register")
				.content(MasterData.asJsonString(buyerDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		WFAssert(currentTest(), (result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}

}
