package com.wellsfargo.training.auction.exception;



import static com.wellsforgo.testutils.TestUtils.currentTest;
import static com.wellsforgo.testutils.TestUtils.exceptionTestFile;
import static com.wellsforgo.testutils.TestUtils.testReport;
import static com.wellsforgo.testutils.TestUtils.WFAssert;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterAll;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.wellsfargo.training.auction.controller.SellerController;
import com.wellsfargo.training.auction.dto.SellerDto;
import com.wellsfargo.training.auction.service.BidsService;
import com.wellsfargo.training.auction.service.SellerService;
import com.wellsforgo.testutils.MasterData;

@WebMvcTest(SellerController.class)
@AutoConfigureMockMvc
public class SellerExceptionTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BidsService bidsService;
	
	@MockBean
	private SellerService sellerService;
	
	

	@AfterAll
	public static void afterAll() {
		testReport();
	}

	@Test
	 void testRegisterSellerInvalidDataException() throws Exception {
		SellerDto sellerDto = MasterData.getSellerDto();
		SellerDto savedSellerDto = MasterData.getSellerDto();

		savedSellerDto.setSellerId(1L);
		sellerDto.setSellerFirstName("Ab");

		when(this.sellerService.registerSeller(sellerDto)).thenReturn(savedSellerDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-auction/api/v1/seller/add-product")
				.content(MasterData.asJsonString(sellerDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		
		WFAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}
	

	
}

