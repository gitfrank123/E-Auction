package com.wellsfargo.training.auction.func;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.entity.BidsEntity;
import com.wellsfargo.training.auction.exceptions.InvalidDataException;
import com.wellsfargo.training.auction.repository.BidsRepository;
import com.wellsfargo.training.auction.service.impl.BidsServiceImpl;
import com.wellsforgo.testutils.MasterData;

@ExtendWith(MockitoExtension.class)
class BidsServiceImplTest {

	@Mock
	BidsRepository bidsRepo;
	@InjectMocks
	BidsServiceImpl bidsServiceImpl;

	@Test
	void testGetBid() throws Exception {
		BidsEntity bid = bidsServiceImpl.getBid(1L);
		System.out.println(bid);
		assertThat(bid).isNull();
	}

	@Test
	void testPlaceBid() throws Exception {
		BidsDto bidsDto = MasterData.getBidsDto();
		BidsDto placeBid = bidsServiceImpl.placeBid(bidsDto);
		assertEquals(placeBid, bidsDto);

	}

	@Test
	void testPlaceBidInvaidData() throws Exception {
		BidsDto bidsDto = MasterData.getBidsDto();
		bidsDto.setBidId(0L);
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> bidsServiceImpl.placeBid(bidsDto))
				.withMessage("Bid not Placed");
	}
	
	@Test
	void testUpdateBidActual() throws Exception {

		BidsDto bidsDto = MasterData.getBidsDto();
		BidsEntity bidsEntit = new BidsEntity();
		bidsEntit.setBidId(2l);
		Mockito.when(bidsRepo.getBidByProductId(2L)).thenReturn(bidsEntit);
		BidsDto placeBid = bidsServiceImpl.updateBid(2L, 238.50);
		assertEquals(placeBid.getBidAmount()!=null, bidsDto.getBidAmount()!=null);

	}

	@Test
	void testUpdateBid() throws Exception {

		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> bidsServiceImpl.updateBid(1L, 238.50))
				.withMessage("Bid Not Found");

	}

	@Test
	void testUpdateBidInvaidData() throws Exception {
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> bidsServiceImpl.updateBid(0L, 230.78))
				.withMessage("Invalid Product Id");
	}

	@Test
	void testGetBids() throws Exception {
		List<BidsDto> bids = new ArrayList<>();
		List<BidsEntity> bidsEntityList = new ArrayList<>(); 
		BidsEntity bidsEntit = new BidsEntity();
		bidsEntit.setBidId(1l);
		bidsEntityList.add(bidsEntit);
		Mockito.when(bidsRepo.getBidsByProductId(1L)).thenReturn(bidsEntityList);
		List<BidsDto> allBidsOnProduct = bidsServiceImpl.getAllBidsOnProduct(1L);
		System.out.println(allBidsOnProduct.size());
		System.out.println(bids.size());
		assertEquals(allBidsOnProduct.size(), 1);

	}

	@Test
	void testGetBidsInvaidData() throws Exception {
		BidsDto bidsDto = MasterData.getBidsDto();
		bidsDto.setBidId(0L);
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> bidsServiceImpl.getAllBidsOnProduct(0L))
				.withMessage("Product Should not be 0");
	}

}
