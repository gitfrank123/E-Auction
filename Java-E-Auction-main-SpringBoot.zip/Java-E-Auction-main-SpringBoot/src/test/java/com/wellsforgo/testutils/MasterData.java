package com.wellsforgo.testutils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.wellsfargo.training.auction.dto.BidsDto;
import com.wellsfargo.training.auction.dto.BuyerDto;
import com.wellsfargo.training.auction.dto.ProductDto;
import com.wellsfargo.training.auction.dto.SellerDto;

public class MasterData {

	public static BidsDto getBidsDto() {
		BidsDto bidsDto = new BidsDto();
		bidsDto.setBidId(1L);
		bidsDto.setBidAmount(25000.0);
		bidsDto.setBuyerId(1L);
		bidsDto.setProductId(1L);
		bidsDto.setBiddingDate(LocalDate.now());
		return bidsDto;
	}

	public static List<BidsDto> getBidsDtoList() {
		List<BidsDto> bidsDtos = new ArrayList<>();
		BidsDto bidsDto = new BidsDto();
		bidsDto.setBidId(1L);
		bidsDto.setBidAmount(25000.0);
		bidsDto.setBuyerId(1L);
		bidsDto.setProductId(1L);
		bidsDto.setBiddingDate(LocalDate.now());
		bidsDtos.add(bidsDto);
		bidsDto = new BidsDto();
		bidsDto.setBidId(2L);
		bidsDto.setBidAmount(18000.0);
		bidsDto.setBuyerId(2L);
		bidsDto.setProductId(2L);
		bidsDto.setBiddingDate(LocalDate.now());
		bidsDtos.add(bidsDto);
		return bidsDtos;

	}

	public static SellerDto getSellerDto() {
		SellerDto sellerDto = new SellerDto();
		sellerDto.setSellerId(1L);
		sellerDto.setSellerFirstName("Leena");
		sellerDto.setSellerLastName("David");
		sellerDto.setSellerEmail("leenadavid@gmail.com");
		sellerDto.setSellerAddress("Mahadevapura");
		sellerDto.setSellerCity("Bangalore");
		sellerDto.setSellerState("Karnataka");
		sellerDto.setSellerPin(560016L);
		sellerDto.setSellerPhone(1234567890L);
		return sellerDto;
	}

	public static List<SellerDto> getSellerDtoList() {
		List<SellerDto> sellerDtos = new ArrayList<>();
		SellerDto sellerDto = new SellerDto();
		sellerDto.setSellerId(1L);
		sellerDto.setSellerFirstName("Leena");
		sellerDto.setSellerLastName("David");
		sellerDto.setSellerEmail("leenadavid@gmail.com");
		sellerDto.setSellerAddress("Mahadevapura");
		sellerDto.setSellerCity("Bangalore");
		sellerDto.setSellerState("Karnataka");
		sellerDto.setSellerPin(560016L);
		sellerDto.setSellerPhone(1234567890L);
		sellerDtos.add(sellerDto);
		sellerDto = new SellerDto();
		sellerDto.setSellerId(2L);
		sellerDto.setSellerFirstName("Vivek");
		sellerDto.setSellerLastName("Gupta");
		sellerDto.setSellerEmail("vivekgupta@gmail.com");
		sellerDto.setSellerAddress("Kalyan Nagar");
		sellerDto.setSellerCity("Bangalore");
		sellerDto.setSellerState("Karnataka");
		sellerDto.setSellerPin(560096L);
		sellerDto.setSellerPhone(6523987415L);
		sellerDtos.add(sellerDto);
		return sellerDtos;
	}

	public static BuyerDto getBuyerDto() {
		BuyerDto buyerDto = new BuyerDto();
		buyerDto.setBuyerId(1L);
		buyerDto.setBuyerFirstName("Rakesh");
		buyerDto.setBuyerLastName("Jayaseelan");
		buyerDto.setBuyerEmail("Rakesh_Admin@gmail.com");
		buyerDto.setBuyerPhone(1234567890L);
		buyerDto.setBuyerAddress("Ambattur");
		buyerDto.setBuyerCity("Chennai");
		buyerDto.setBuyerState("Tamilnadu");
		buyerDto.setBuyerPin(600053L);
		return buyerDto;
	}

	public static List<BuyerDto> getBuyerDtoList() {
		List<BuyerDto> buyerDtos = new ArrayList<>();
		BuyerDto buyerDto = new BuyerDto();
		buyerDto.setBuyerId(1L);
		buyerDto.setBuyerFirstName("Rakesh");
		buyerDto.setBuyerLastName("Jayaseelan");
		buyerDto.setBuyerEmail("Rakesh_Admin@gmail.com");
		buyerDto.setBuyerPhone(1234567890L);
		buyerDto.setBuyerAddress("Ambattur");
		buyerDto.setBuyerCity("Chennai");
		buyerDto.setBuyerState("Tamilnadu");
		buyerDto.setBuyerPin(600053L);
		buyerDtos.add(buyerDto);
		buyerDto = new BuyerDto();
		buyerDto.setBuyerId(2L);
		buyerDto.setBuyerFirstName("Prakash");
		buyerDto.setBuyerLastName("Kumar");
		buyerDto.setBuyerEmail("prakash_admin@gmail.com");
		buyerDto.setBuyerPhone(5632541789L);
		buyerDto.setBuyerAddress("Avadi");
		buyerDto.setBuyerCity("Chennai");
		buyerDto.setBuyerState("Tamilnadu");
		buyerDto.setBuyerPin(600054L);
		buyerDtos.add(buyerDto);
		return buyerDtos;

	}

	public static ProductDto getProductDto() {
		ProductDto productDto = new ProductDto();
		productDto.setProductId(1L);
		productDto.setProductName("Oil painting");
		productDto.setSellerId(1L);
		productDto.setShortDescription("Oil painting");
		productDto.setDetailedDescription("multi color oil painitng");
		productDto.setStartingPrice(1900.0);
		productDto.setProductCategory("Painting");
		productDto.setBidEndDate(LocalDate.of(2021, 11, 20));
		return productDto;

	}

	public static List<ProductDto> getProductDtoList() {
		List<ProductDto> productDtos = new ArrayList<>();
		ProductDto productDto = new ProductDto();
		productDto.setProductId(1L);
		productDto.setProductName("Nature Painting");
		productDto.setSellerId(1L);
		productDto.setShortDescription("Canvas painting");
		productDto.setDetailedDescription("multi color oil painting");
		productDto.setStartingPrice(1500.0);
		productDto.setProductCategory("Painting");
		productDto.setBidEndDate(LocalDate.of(2021, 11, 20));
		productDtos.add(productDto);
		productDto = new ProductDto();
		productDto.setProductId(1L);
		productDto.setProductName("Acrylic Painting");
		productDto.setSellerId(1L);
		productDto.setShortDescription("Acrylic painting");
		productDto.setDetailedDescription("multi color Acrylic painting");
		productDto.setStartingPrice(1800.0);
		productDto.setProductCategory("Painting");
		productDto.setBidEndDate(LocalDate.of(2021, 11, 20));
		productDtos.add(productDto);
		return productDtos;

	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.registerModule(new JavaTimeModule());
			mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			final String jsonContent = mapper.writeValueAsString(obj);

			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
