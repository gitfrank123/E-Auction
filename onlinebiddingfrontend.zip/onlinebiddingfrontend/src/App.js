import React, { Component } from 'react';
import ReactTable from "react-table-6";
import "react-table-6/react-table.css";
import axios from 'axios'
class App extends Component {
  state = {
    data: []
  }
  componentDidMount() {

    axios.get('http://localhost:8080/online-auction-system/e-auction/api/v1/seller/show-bids/2')
      .then(response => {this.setState({ data: response.data})
    console.log("response data",response.data)
    });
  }
  render() {    
    const columns = [{
      Header: 'BuyerId',
      accessor: 'buyerId'
    },{
      Header: 'BidAmount',
      accessor: 'bidAmount'
    }, {
      Header: 'BiddingDate',
      accessor: 'biddingDate'
    },
    {
      Header: 'ProductId',
      accessor: 'productId'
    }
    ]
    return (
      <div>
        
        <ReactTable
          data={this.state.data}
          columns={columns}
          defaultPageSize={5}
          pageSizeOptions={[5,10,20,50,100]}
        />
      </div>
    )
  }
}
export default App; 